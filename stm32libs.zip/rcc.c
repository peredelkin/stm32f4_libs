/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   rcc.c
 * Author: ruslan
 * 
 * Created on 10 февраля 2018 г., 22:59
 */

#include "rcc.h"
